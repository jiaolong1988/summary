package com.example.easyexcel.demo;

/**
 * 测试工具类
 *
 * @author fraser
 * @date 2019/10/6 9:46 AM
 */
public class TestUtils {

	public static String getPath() {
		return TestUtils.class.getResource("/").getPath();
	}
}
