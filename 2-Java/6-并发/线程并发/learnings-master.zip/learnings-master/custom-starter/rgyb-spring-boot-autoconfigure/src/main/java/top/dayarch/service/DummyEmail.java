package top.dayarch.service;

/**
 * Dummy 类，为了条件注解使用
 *
 * @author fraser
 * @date 2019/10/15 5:00 PM
 */
public class DummyEmail {
}
