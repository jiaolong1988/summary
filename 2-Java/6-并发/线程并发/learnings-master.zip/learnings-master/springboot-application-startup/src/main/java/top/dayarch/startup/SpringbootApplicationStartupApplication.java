package top.dayarch.startup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootApplicationStartupApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootApplicationStartupApplication.class, args);
	}

}
