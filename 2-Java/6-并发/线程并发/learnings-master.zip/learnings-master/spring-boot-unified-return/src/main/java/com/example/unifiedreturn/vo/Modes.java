package com.example.unifiedreturn.vo;

/**
 * 模式枚举
 *
 * @author fraser
 * @date 2019/12/12 1:51 PM
 */
public enum Modes {
	ALPHA, BETA;
}
