
prop(){
    grep "${1}" datadencrypt.properties | cut -d'=' -f2 | sed 's/\r//'
}

a=$(prop jdbc.jdbcUrl | cut -d'@' -f2)
echo $a

#清理内存 当前内存小于指定 值
memory=`free -h| grep Mem| awk '{print $4}' | sed "s/M//"| sed "s/G//"`
echo "[*]current: $memory   "
flag=$(()) 
if [ $memory -lt 500 ];then
	echo "[*]memory: $memory   clear Memory"
	echo 1 > /proc/sys/vm/drop_caches
	sleep 5
fi


