#配置文件地址
proDir='./config/dataencrypt.properties'
proFilePath=`ls ${proDir}`

echo "jiaolong... $proFilePath"

#配置文件信息
prop(){
    grep "${1}" $proFilePath | cut -d'=' -f2 | sed 's/\r//'
}

#查询任务参数
systmeCode=$(prop sourceSystem)
encryptType=$(prop server_cfg.encryptMethod)
tmpTableName=$(prop tempTableName)

#数据库账号
dbUser=$(prop jdbc.user)
dbPwd=$(prop jdbc.password)
dbUrl=$(prop jdbc.jdbcUrl | cut -d'@' -f2)

echo "systmeCode: $systmeCode    encryptType: $encryptType    tmpTableName: $tmpTableName"
echo $dbUser $dbPwd $dbUrl

#sql脚本模板
sqlFile=`ls ./sqlScript/*.sql`

#真正的可运行的sql脚本
runSqlFile="./sqlScript/install.sql"
echo "bak: $runSqlFile" 

#替换文本 一次替换
#sed  -i\ "s/#systmeCode#/$systmeCode/g" $runSqlFile
#sed  -i\ "s/#encryptType#/$encryptType/g" $runSqlFile
#sed  -i\ "s/#tmpTableName#/$tmpTableName/g" $runSqlFile
$(cat sqlScript/create_temp_table.sql | sed "s/#systmeCode#/$systmeCode/g" | \
 sed  "s/#encryptType#/$encryptType/g" |  \
 sed "s/#tmpTableName#/$tmpTableName/g" > $runSqlFile) \

#登录oracle 执行sql脚本
sqlplus $dbUser/$dbPwd@$dbUrl <<EOF
  start ${runSqlFile}
exit; 
EOF


