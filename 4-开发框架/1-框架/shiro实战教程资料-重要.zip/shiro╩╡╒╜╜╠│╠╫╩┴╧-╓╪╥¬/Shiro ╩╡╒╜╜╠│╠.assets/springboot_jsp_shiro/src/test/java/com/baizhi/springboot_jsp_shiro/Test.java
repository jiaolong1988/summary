package com.baizhi.springboot_jsp_shiro;

public class Test {
    public static void main(String[] args) {
        int i = 15 & 3104;
        System.out.println(i);
    }
}
