cd `dirname $0`
CURRDIR=`pwd`
nginx -c "$CURRDIR/nginx.conf"
