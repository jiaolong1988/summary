# nginx  -c /root/server-admin/nginx_admin.conf 
cd `dirname $0`
CURRDIR=`pwd`
nginx -c "$CURRDIR/nginx.conf"
