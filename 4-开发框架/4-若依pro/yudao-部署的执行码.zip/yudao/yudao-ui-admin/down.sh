cd `dirname $0`
CURRDIR=`pwd`
#nginx -c "$CURRDIR/nginx_admin.conf" -s quit
ps -ef|grep "$CURRDIR/nginx.conf"|grep -v grep |awk '{print $2}'|xargs kill -QUIT
