APPDIR=/work/projects/yudao-server
cd `dirname $0`
CURRDIR=`pwd`
if  [ "$APPDIR" = "$CURRDIR" ]
then
	counter=`ps -ef | grep "$APPDIR" | grep -v grep | wc -l`
	if  [ $counter -ge 1 ]
	then
		ps -ef|grep "$APPDIR"|grep -v grep |awk '{print $2}'|xargs kill -9
	fi
	sleep 1
	counter=`ps -ef | grep "$APPDIR" | grep -v grep | wc -l`
	if  [ $counter -eq 0 ]
	then
		echo "******Current service $APPDIR [Stopped！]******"
	else
		echo "******Current service $APPDIR [Not Stopped]，Please stop manually******"
	fi
else
	 echo "***********************************************************************"
	 echo "******APPDIR=$APPDIR ******"
	 echo "******CURRDIR=$CURRDIR ******"
	 echo "***********************************************************************"
fi
