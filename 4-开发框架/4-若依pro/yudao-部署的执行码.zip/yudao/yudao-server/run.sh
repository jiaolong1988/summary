rm -rf nohup.out 
nohup java -jar  yudao-server.jar -Xms512m -Xmx512m --spring.config.location=/work/projects/yudao-server/config/  > nohup.out 2>&1 &
